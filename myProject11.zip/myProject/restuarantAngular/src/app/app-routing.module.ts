import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowDataComponent } from './components/show-data/show-data.component';
import { MenuComponent } from './components/menu/menu.component';

const routes: Routes = [
  {'path': "" , component:ShowDataComponent},
  {'path': "restaurant" , component:ShowDataComponent},
  {'path': "menu_item" , component:MenuComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
