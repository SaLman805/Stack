import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {
  url = "http://localhost:1234/";

  constructor(public http: HttpClient) { }

  getRestaurant(id): any {
    // this.getMenu(id);
    return this.http.get(this.url + id);
  }
  getMenu(id): any {
    alert(this.url + 'menus/' + id)
    return this.http.get(this.url + 'menus/' + id);
  }
}
