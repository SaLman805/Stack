import { Component, OnInit } from '@angular/core';
import { RestaurantService } from 'src/app/services/restaurant.service';

@Component({
  selector: 'app-show-data',
  templateUrl: './show-data.component.html',
  styleUrls: ['./show-data.component.css']
})
export class ShowDataComponent implements OnInit {

  public data = [];
  public menu = [];
  resId: number;
  constructor(public service: RestaurantService) { }

  ngOnInit() {

  }

  getRestaurant() {
    this.service.getRestaurant(this.resId).subscribe(values => {
      this.data = values[0];
      this.getMenus();
    });
  }
  getMenus() {
    this.service.getMenu(this.resId).subscribe(values => {
      // alert(values);
      this.menu = values;
    });
  }
}
