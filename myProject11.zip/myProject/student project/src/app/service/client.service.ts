import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ClientService {
  private url: string = 'http://localhost:1234/';
  constructor(private http: HttpClient) { }
  getAll(): any {
    return this.http.get(this.url);
  }

  find(id: number): any {
    let tempUrl = this.url + id;
    console.log(tempUrl);
    return this.http.get(tempUrl);
  }

  insert(Student: any) {
    return this.http.post(this.url, Student, { responseType: 'text' });
  }
  delete(no: number): any {
    let tempUrl = this.url + no;
    return this.http.delete(tempUrl, { responseType: 'text' });
  }
  update(Student: any) {
    return this.http.put(this.url, Student, { responseType: 'text' });
  }
}
