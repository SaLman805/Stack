import { Component, OnInit } from '@angular/core';
import { ClientService } from 'src/app/service/client.service';
import { Student } from 'src/app/models/student'

@Component({
  selector: 'app-show-data',
  templateUrl: './show-data.component.html',
  styleUrls: ['./show-data.component.css']
})
export class ShowDataComponent implements OnInit {
  public selectedStudent = false;
  constructor(public myservice: ClientService) {

  }
  public data: [];
  public editable: any;
  ngOnInit() {
    this.showData();
    this.editable = new Student(0,'','',0)
  }
  findStudent(id) {
    this.selectedStudent = true;
    this.myservice.find(id).subscribe(arg => {
      this.editable = arg[0];
    });
  }

  showData(): any {
    this.myservice.getAll().subscribe(values => this.data = values);
  }

  updateRecord() {
    this.myservice.update(this.editable).subscribe(arg => {
      alert(arg);
      this.showData();
    });
    this.selectedStudent = false;
  }
  deleteStudent(id) {
    this.myservice.delete(id).subscribe(arg =>{ alert(arg)
    this.showData();
    });
  }
  hide(){
    this.selectedStudent = false;
  }

}
