import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatedata',
  templateUrl: './updatedata.component.html',
  styleUrls: ['./updatedata.component.css']
})
export class UpdatedataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
