import { Component, OnInit } from '@angular/core';
import { ClientService } from 'src/app/service/client.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-add-data',
  templateUrl: './add-data.component.html',
  styleUrls: ['./add-data.component.css']
})
export class AddDataComponent implements OnInit {

  public sId: number;
  public sName: string;
  public sAddress: string;
  public sNumber: number;

  constructor(public myservice: ClientService, public router : Router) { }

  ngOnInit() {
  }
  submit() {
    let rec = { sId: this.sId, sName: this.sName, sAddress: this.sAddress, sNumber: this.sNumber };
    this.myservice.insert(rec).subscribe(values => {
      alert(values);
      this.router.navigate(['/show_data'])
    });
  }
}
