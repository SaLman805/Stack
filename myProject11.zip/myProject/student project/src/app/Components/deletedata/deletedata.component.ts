import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletedata',
  templateUrl: './deletedata.component.html',
  styleUrls: ['./deletedata.component.css']
})
export class DeletedataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
