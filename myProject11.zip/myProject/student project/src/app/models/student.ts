export class Student {
    private sId;
    private sName;
    private sNumber;
    private sAddress;

    constructor(id,name,number,address){
        this.sId=id;
        this.sName=name;
        this.sNumber=number;
        this.sAddress=address;
    }
}
