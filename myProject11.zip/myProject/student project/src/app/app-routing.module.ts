import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowDataComponent } from './Components/show-data/show-data.component';
import { AddDataComponent } from './Components/add-data/add-data.component';

const routes: Routes = [
  {'path': "", component: ShowDataComponent },
  {'path': "show_data", component: ShowDataComponent },
  {'path': "add_data", component: AddDataComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
