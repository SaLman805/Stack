//This example contains the program to expose the CRUD operations of Database thro a REST service..
var app = require('express')();
var parser = require('body-parser');
var util = require('util');
//npm install body-parser
//data posted by the user thro ajax will be sent in the form of body object created as field in the req object. U need a parser to convert the data into an encoded format understandable to the server. body-parser is a nodejs package that inserts a body field into the req object which can be programmatically accessed from the nodejs application...


app.use(parser.urlencoded({extended:true}));//allows body to be posted as JSON format...
app.use(parser.json());

//few more to be added to enable cors in our application....
app.use((req, res, next)=>{
	res.header('Access-Control-Allow-Origin', '*');
	res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE');
	res.header('Access-Control-Allow-Headers', '*');
	next();
})

//Function loads the mysql driver for mysqlDB connection and creates object that interact with the db connection....
function createConnection(){
	var sql = require('mysql');
	var config ={
		server:'localhost' ,
		user:'root',
		password:'',
		database:'Student'
	};
	var con = sql.createConnection(config);
	return con;
}

//The app object of the Express has apis like get, post, put and delete to perform the required operations of REST...
//url:http://localhost:1234/
app.get('/', (req, res)=>{
	var con = createConnection();
	var strQuery = "SELECT * FROM stable";
	con.query(strQuery, (e, results)=>{
		res.send(JSON.stringify(results))	
	})//gets all the data under this url....
});

app.get('/:id', (req, res)=>{
	var id = req.params.id;//params gets the query string parameters of the URL....
	var con = createConnection();
	var strQuery = "SELECT * FROM stable WHERE sId =" + id;
	con.query(strQuery, (e, results)=>{
		res.send(JSON.stringify(results))	
	})//gets all the data under this url....
});

app.post('/', (req, res)=>{
	var data = req.body;
	var con = createConnection();
	var query = util.format("Insert into stable values('%s','%s','%s','%s')", data.sId, data.sName, data.sNumber, data.sAddress);
	console.log(query);
	con.query(query, (e, results)=>{
		if(e) res.send("Error occured");
		res.send("Insertion successfull");
	})
});

app.put('/', (req, res)=>{
	var data = req.body;
	var con = createConnection();
	var query = util.format("Update stable set sName ='%s' ,sNumber = '%s' sAddress = '%s' where sId = '%s'", data.sName, data.sNumber, data.sAddress, data.sId);
	console.log(query);
	con.query(query, (e, results)=>{
		if(e) res.send("Error occured");
		res.send("Updation successfull");
	})
})

app.delete('/:id', (req, res)=>{
		var id = req.params.id;//params gets the query string parameters of the URL....
	var con = createConnection();
	var strQuery = "DELETE FROM stable WHERE sId =" + id;
	con.query(strQuery, (e, results)=>{
		if(e) res.send(JSON.stringify(e));
		res.send("deletion is successfull")	
	})//gets all the data under this url....
})

var server = app.listen(1234, ()=>{
	console.log("Server available at 1234");
})





