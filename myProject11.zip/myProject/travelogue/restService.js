var app = require("express")();


function createconnection() {
    var sql = require("mysql");
    var config = {
        server: "localhost",
        user: "root",
        password: "",
        database: "cdactraining"
    }
    var con = sql.createConnection(config);
    return con;
}

app.get('/', (req, res) => {
    var con = createconnection();
    var abc = "select * from travelinfo";
    con.query(abc, (err, result) => {
        if (err) res.send("errored occured");
        res.send(result);
    });
})

app.listen(1234, () => {
    console.log("Server available at 1234");
})