<!DOCTYPE html>
<html lang="en">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<head>    

</head>
<body>
<div style="margin-top:60px; width:700px;margin-left:200px">
<p><h1>User Registration</h1></p>
<form action="travel_info_process.php" method="POST">
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Destination</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="tDest" placeholder="Enter your Destination">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Date of travel</label>
    <div class="col-sm-10">
      <input type="date" class="form-control" name="tDate">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Keywords</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="tKey" placeholder="Enter Keywords">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Description</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="tDesc" placeholder="Enter Desrciption">
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit Info</button>
    </div>
  </div>
</form>
<a href="index.php" style="color:red">Go Home Page</a>
</div>
</body>
</html>