<?php
require("repository.php");

$logMail = $_POST['rMail'];
$logPass = $_POST['rPass'];

userLogin($logMail,$logPass);
echo "Login Successfull";
?>
<br>
<a href="travel_info.php">Click here to add travel info</a>