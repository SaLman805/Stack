<?php
require("repository.php");

$trDest = $_POST['tDest'];
$trDate = $_POST['tDate'];
$trKey = $_POST['tKey'];
$trDesc = $_POST['tDesc'];

travelInfo($trDest,$trDate,$trKey,$trDesc);
echo "Insertion Successfull";
?>
<br>
<a href="index.php">Home Page</a>