<?php
require("repository.php");

$regName = $_POST['rName'];
$regMail = $_POST['rMail'];
$regCity = $_POST['rCity'];
$regUname = $_POST['rUname'];
$regPass = $_POST['rPass'];


insertUser($regName,$regMail,$regCity,$regUname,$regPass);
echo "Registration successfully";
?>
<a href="index.php">Go Back</a>