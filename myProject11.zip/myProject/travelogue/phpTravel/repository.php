<?php

function createConnection()
{
    $server = "localhost";
    $user = "root";
    $password = "";
    $db = "cdactraining";

    $con = new mysqli($server, $user, $password, $db);
    return $con;
}


function insertUser($name, $mail, $city, $uname, $pwd)
{
    $con = createConnection();
    $query = sprintf("insert into travelogue(name,email,hometown,username,password) values('%s','%s','%s','%s','%s')", $name, $mail, $city,$uname,$pwd);
    $con->query($query);
}
function travelInfo($dest, $date, $key, $desc)
{
    $con = createConnection();
    $query = sprintf("insert into travelinfo(Destination,dateot,Keywords,Description) values('%s','%s','%s','%s')", $dest, $date, $key,$desc);
    $con->query($query);
}

function userLogin($mail, $pwd)
{
    $con = createConnection();
    $query = sprintf("select * from travelogue where mail , password = '%s','%s'", $mail,$pwd);
    $con->query($query);
}

